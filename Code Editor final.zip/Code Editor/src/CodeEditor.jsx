// import { useState } from 'react';
// import { Box, Button, Textarea, Spinner, VStack, Text } from '@chakra-ui/react';
// import axios from 'axios';

// const CodeEditor = () => {
//   const [code, setCode] = useState('');
//   const [output, setOutput] = useState('');
//   const [loading, setLoading] = useState(false);

//   const runPythonCode = async (code) => {
//     setLoading(true);
//     setOutput(''); // Clear previous output
//     try {
//       // Submit code for execution
//       const response = await axios.post(
//         'https://judge0-ce.p.rapidapi.com/submissions',
//         {
//           language_id: 71, // Python 3
//           source_code: code,
//           stdin: '', // Optional: Input to the code
//         },
//         {
//           headers: {
//             'X-RapidAPI-Key': import.meta.env.VITE_RAPIDAPI_KEY, // Ensure this is set in your .env file
//             'X-RapidAPI-Host': 'judge0-ce.p.rapidapi.com', // Correct host for Judge0 CE
//             'Content-Type': 'application/json',
//           },
//         }
//       );
  
//       const { token } = response.data; // Get the token from the response
  
//       // Fetch the execution result using the token
//       const resultResponse = await axios.get(
//         `https://judge0-ce.p.rapidapi.com/submissions/${token}`,
//         {
//           headers: {
//             'X-RapidAPI-Key': import.meta.env.VITE_RAPIDAPI_KEY, // Same API key here
//             'X-RapidAPI-Host': 'judge0-ce.p.rapidapi.com', // Correct host for Judge0 CE
//           },
//         }
//       );
  
//       const result = resultResponse.data;
//       if (result.status && result.status.id === 3) { // Status 3 means "Accepted"
//         // Successfully executed
//         setOutput(result.stdout || 'No output');
//       } else {
//         // Error in code execution
//         setOutput(result.stderr || 'Error occurred');
//       }
//     } catch (error) {
//       console.error('Error executing Python code:', error);
//       setOutput(`Error: ${error.message}`);
//       if (error.response) {
//         console.error('API response error:', error.response.data);
//       }
//     } finally {
//       setLoading(false);
//     }
//   };
  

//   return (
//     <VStack spacing={4} align="stretch" w="full" maxW="container.md" p={4}>
//       <Textarea
//         value={code}
//         onChange={(e) => setCode(e.target.value)}
//         placeholder="Write your Python code here..."
//         size="lg"
//         minHeight="200px"
//         borderColor="gray.300"
//         focusBorderColor="blue.500"
//       />
//       <Button
//         colorScheme="blue"
//         onClick={() => runPythonCode(code)}
//         isLoading={loading}
//         loadingText="Running..."
//         size="lg"
//         isFullWidth
//       >
//         Run Code
//       </Button>
//       <Box w="full" p={4} border="1px" borderColor="gray.200" borderRadius="md">
//         {loading ? (
//           <Spinner size="lg" />
//         ) : (
//           <Text fontSize="md" whiteSpace="pre-wrap">
//             {output || 'Output will be displayed here.'}
//           </Text>
//         )}
//       </Box>
//     </VStack>
//   );
// };

// export default CodeEditor;

// import React, { useState } from 'react';
// import axios from 'axios';

// const CodeEditor = () => {
//   const [code, setCode] = useState(''); // Code input by the user
//   const [stdin, setStdin] = useState(''); // Input for stdin
//   const [language, setLanguage] = useState('python'); // Default to Python
//   const [output, setOutput] = useState(''); // Output of the code execution
//   const [loading, setLoading] = useState(false); // Loading state for button

//   // Handle code changes in the editor
//   const handleCodeChange = (e) => setCode(e.target.value);

//   // Handle stdin changes
//   const handleStdinChange = (e) => setStdin(e.target.value);

//   // Handle language change
//   const handleLanguageChange = (e) => setLanguage(e.target.value);

//   const runCode = async () => {
//     setLoading(true);
//     setOutput(''); // Clear previous output

//     try {
//       // Send the request to the Piston API
//       const response = await axios.post('https://emkc.org/api/v2/piston/execute', {
//         language, // Selected language
//         version: '*', // Use the latest version available
//         files: [
//           {
//             name: 'main', // Name of the file
//             content: code, // Code content
//           },
//         ],
//         stdin, // Input for stdin
//       });

//       const { run } = response.data;

//       // Check if the execution was successful
//       if (run && run.stdout) {
//         setOutput(run.stdout); // Output from stdout
//       } else if (run && run.stderr) {
//         setOutput(`Error: ${run.stderr}`); // Output from stderr
//       } else {
//         setOutput('No output or error occurred');
//       }
//     } catch (error) {
//       console.error('Error executing code:', error);

//       // Display error information
//       setOutput(`Error: ${error.message}`);
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div>
//       <div>
//         <select onChange={handleLanguageChange} value={language}>
//           {/* Add more languages as needed */}
//           <option value="python">Python</option>
//           <option value="javascript">JavaScript</option>
//           <option value="java">Java</option>
//           <option value="cpp">C++</option>
//         </select>
//       </div>
//       <div>
//         <textarea
//           value={code}
//           onChange={handleCodeChange}
//           rows={10}
//           cols={50}
//           placeholder="Write your code here"
//         ></textarea>
//       </div>
//       <div>
//         <textarea
//           value={stdin}
//           onChange={handleStdinChange}
//           rows={5}
//           cols={50}
//           placeholder="Input for your program (stdin)"
//         ></textarea>
//       </div>
//       <div>
//         <button onClick={runCode} disabled={loading}>
//           {loading ? 'Running...' : 'Run Code'}
//         </button>
//       </div>
//       <div>
//         <h3>Output:</h3>
//         <pre>{output}</pre>
//       </div>
//     </div>
//   );
// };

// export default CodeEditor;


// import "./index.css"
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const CODE_SNIPPETS = {
//   python: `# Python code snippet\nprint("Hello, World!")`,
//   javascript: `// JavaScript code snippet\nconsole.log("Hello, World!");`,
//   java: `// Java code snippet\npublic class Main {\n    public static void main(String[] args) {\n        System.out.println("Hello, World!");\n    }\n}`,
//   cpp: `// C++ code snippet\n#include <iostream>\nusing namespace std;\n\nint main() {\n    cout << "Hello, World!" << endl;\n    return 0;\n}`
// };

// const CodeEditor = () => {
//   const [code, setCode] = useState(CODE_SNIPPETS['python']); // Default to Python
//   const [stdin, setStdin] = useState(''); // Input for stdin
//   const [language, setLanguage] = useState('python'); // Default language is Python
//   const [output, setOutput] = useState(''); // Output of code execution
//   const [loading, setLoading] = useState(false); // Loading state for button

//   // Reset code snippet when language changes
//   const handleLanguageChange = (e) => {
//     const selectedLanguage = e.target.value;
//     setLanguage(selectedLanguage);
//     setCode(CODE_SNIPPETS[selectedLanguage]); // Load default code snippet for the selected language
//   };

//   const handleCodeChange = (e) => setCode(e.target.value);

//   const handleStdinChange = (e) => setStdin(e.target.value);

//   const runCode = async () => {
//     setLoading(true);
//     setOutput(''); // Clear previous output

//     try {
//       // Send the request to the Piston API
//       const response = await axios.post('https://emkc.org/api/v2/piston/execute', {
//         language, // Selected language
//         version: '*', // Use the latest version available
//         files: [
//           {
//             name: 'main', // Name of the file
//             content: code, // Code content
//           },
//         ],
//         stdin, // Input for stdin
//       });

//       const { run } = response.data;

//       if (run && run.stdout) {
//         setOutput(run.stdout); // Output from stdout
//       } else if (run && run.stderr) {
//         setOutput(`Error: ${run.stderr}`); // Output from stderr
//       } else {
//         setOutput('No output or error occurred');
//       }
//     } catch (error) {
//       console.error('Error executing code:', error);
//       setOutput(`Error: ${error.message}`);
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="editor-container">
//       <div>
//         <select onChange={handleLanguageChange} value={language}>
//           <option value="python">Python</option>
//           <option value="javascript">JavaScript</option>
//           <option value="java">Java</option>
//           <option value="cpp">C++</option>
//         </select>
//       </div>
//       <div>
//         <textarea
//           value={code}
//           onChange={handleCodeChange}
//           rows={10}
//           cols={50}
//           placeholder="Write your code here"
//         ></textarea>
//       </div>
//       <div>
//         <textarea
//           value={stdin}
//           onChange={handleStdinChange}
//           rows={5}
//           cols={50}
//           placeholder="Input for your program (stdin)"
//         ></textarea>
//       </div>
//       <div>
//         <button onClick={runCode} disabled={loading}>
//           {loading ? 'Running...' : 'Run Code'}
//         </button>
//       </div>
//       <div className="output">
//         <h3>Output:</h3>
//         <pre>{output}</pre>
//       </div>
//     </div>
//   );
// };

// export default CodeEditor;


// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import MonacoEditor from '@monaco-editor/react';
// import './index.css';

// const CodeEditor = () => {
//   const [code, setCode] = useState(''); // Code input by the user
//   const [stdin, setStdin] = useState(''); // Input for stdin
//   const [language, setLanguage] = useState('python'); // Default to Python
//   const [output, setOutput] = useState(''); // Output of the code execution
//   const [loading, setLoading] = useState(false); // Loading state for button
//   const [snippets, setSnippets] = useState({}); // To store snippets fetched from the API

//   // Hardcoded code snippets for different languages
//   const codeSnippets = {
//     python: `print("Hello, World!")`,
//     javascript: `console.log("Hello, World!");`,
//     java: `public class Main { public static void main(String[] args) { System.out.println("Hello, World!"); } }`,
//     cpp: `#include <iostream> using namespace std; int main() { cout << "Hello, World!"; return 0; }`,
//   };

//   // Set default code when the component mounts
//   useEffect(() => {
//     setSnippets(codeSnippets);
//     setCode(codeSnippets[language]); // Set the default code for the default language (Python)
//   }, []); // Only run once when the component mounts

//   // Reset code snippet when language changes
//   const handleLanguageChange = (e) => {
//     const selectedLanguage = e.target.value;
//     setLanguage(selectedLanguage);
//     setCode(snippets[selectedLanguage] || ''); // Load code snippet for the selected language
//   };

//   const handleCodeChange = (value) => setCode(value);

//   const handleStdinChange = (e) => setStdin(e.target.value);

//   const runCode = async () => {
//     setLoading(true);
//     setOutput(''); // Clear previous output

//     try {
//       // Send the request to the Piston API
//       const response = await axios.post('https://emkc.org/api/v2/piston/execute', {
//         language, // Selected language
//         version: '*', // Use the latest version available
//         files: [
//           {
//             name: 'main', // Name of the file
//             content: code, // Code content
//           },
//         ],
//         stdin, // Input for stdin
//       });

//       const { run } = response.data;

//       if (run && run.stdout) {
//         setOutput(run.stdout); // Output from stdout
//       } else if (run && run.stderr) {
//         setOutput(`Error: ${run.stderr}`); // Output from stderr
//       } else {
//         setOutput('No output or error occurred');
//       }
//     } catch (error) {
//       console.error('Error executing code:', error);
//       setOutput(`Error: ${error.message}`);
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="editor-container">
//       <div>
//         <select onChange={handleLanguageChange} value={language}>
//           <option value="python">Python</option>
//           <option value="javascript">JavaScript</option>
//           <option value="java">Java</option>
//           <option value="cpp">C++</option>
//         </select>
//       </div>
//       <div>
//         <MonacoEditor
//           value={code}
//           onChange={handleCodeChange}
//           language={language}
//           theme="vs-dark"
//           height="400px"
//           options={{
//             selectOnLineNumbers: true,
//             minimap: { enabled: false },
//           }}
//         />
//       </div>
//       <div>
//         <textarea
//           value={stdin}
//           onChange={handleStdinChange}
//           rows={5}
//           cols={50}
//           placeholder="Input for your program (stdin)"
//         ></textarea>
//       </div>
//       <div>
//         <button onClick={runCode} disabled={loading}>
//           {loading ? 'Running...' : 'Run Code'}
//         </button>
//       </div>
//       <div>
//         <h3>Output:</h3>
//         <pre>{output}</pre>
//       </div>
//     </div>
//   );
// };

// export default CodeEditor;


// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import MonacoEditor from '@monaco-editor/react';
// import './index.css';

// const CodeEditor = () => {
//   const [code, setCode] = useState(''); // Code input by the user
//   const [stdin, setStdin] = useState(''); // Input for stdin
//   const [language, setLanguage] = useState('python'); // Default to Python
//   const [output, setOutput] = useState([]); // Output of the code execution (now an array)
//   const [loading, setLoading] = useState(false); // Loading state for button
//   const [snippets, setSnippets] = useState({}); // To store snippets fetched from the API

//   // Hardcoded code snippets for different languages
//   const codeSnippets = {
//     python: `print("Hello, World!")`,
//     javascript: `console.log("Hello, World!");`,
//     java: `public class Main { public static void main(String[] args) { System.out.println("Hello, World!"); } }`,
//     cpp: `#include <iostream> using namespace std; int main() { cout << "Hello, World!"; return 0; }`,
//   };

//   // Set default code when the component mounts
//   useEffect(() => {
//     setSnippets(codeSnippets);
//     setCode(codeSnippets[language]); // Set the default code for the default language (Python)
//   }, []); // Only run once when the component mounts

//   // Reset code snippet when language changes
//   const handleLanguageChange = (e) => {
//     const selectedLanguage = e.target.value;
//     setLanguage(selectedLanguage);
//     setCode(snippets[selectedLanguage] || ''); // Load code snippet for the selected language
//   };

//   const handleCodeChange = (value) => setCode(value);

//   const handleStdinChange = (e) => setStdin(e.target.value);

//   const runCode = async () => {
//     setLoading(true);
//     setOutput([]); // Clear previous output

//     try {
//       // Send the request to the Piston API
//       const response = await axios.post('https://emkc.org/api/v2/piston/execute', {
//         language, // Selected language
//         version: '*', // Use the latest version available
//         files: [
//           {
//             name: 'main', // Name of the file
//             content: code, // Code content
//           },
//         ],
//         stdin, // Input for stdin
//       });

//       const { run } = response.data;

//       let newOutput = [];

//       if (run && run.stdout) {
//         newOutput.push({ type: 'stdout', message: run.stdout }); // Output from stdout
//       } else if (run && run.stderr) {
//         newOutput.push({ type: 'stderr', message: `Error: ${run.stderr}` }); // Output from stderr
//       } else {
//         newOutput.push({ type: 'stderr', message: 'No output or error occurred' });
//       }

//       setOutput(newOutput); // Set output as an array
//     } catch (error) {
//       console.error('Error executing code:', error);
//       setOutput([{ type: 'stderr', message: `Error: ${error.message}` }]);
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="editor-container">
//       <div>
//         <select onChange={handleLanguageChange} value={language}>
//           <option value="python">Python</option>
//           <option value="javascript">JavaScript</option>
//           <option value="java">Java</option>
//           <option value="cpp">C++</option>
//         </select>
//       </div>
//       <div>
//         <MonacoEditor
//           value={code}
//           onChange={handleCodeChange}
//           language={language}
//           theme="vs-dark"
//           height="400px"
//           options={{
//             selectOnLineNumbers: true,
//             minimap: { enabled: false },
//           }}
//         />
//       </div>
//       <div>
//         <textarea
//           value={stdin}
//           onChange={handleStdinChange}
//           rows={5}
//           cols={50}
//           placeholder="Input for your program (stdin)"
//         ></textarea>
//       </div>
//       <div>
//         <button onClick={runCode} disabled={loading}>
//           {loading ? 'Running...' : 'Run Code'}
//         </button>
//       </div>
//       <div>
//         <h3>Output:</h3>
//         {output.map((item, index) => (
//           <pre key={index} style={{ color: item.type === 'stderr' ? 'red' : 'green' }}>
//             {item.message}
//           </pre>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default CodeEditor;


import React, { useState, useEffect } from 'react';
import axios from 'axios';
import MonacoEditor from '@monaco-editor/react';
import './index.css';

const CodeEditor = () => {
  const [code, setCode] = useState(''); // Code input by the user
  const [stdin, setStdin] = useState(''); // Input for stdin
  const [language, setLanguage] = useState('python'); // Default to Python
  const [output, setOutput] = useState([]); // Output of the code execution (now an array)
  const [loading, setLoading] = useState(false); // Loading state for button
  const [snippets, setSnippets] = useState({}); // To store snippets fetched from the API

  // Hardcoded code snippets for different languages
  const codeSnippets = {
    python: `print("Hello, World!")`,
    javascript: `console.log("Hello, World!");`,
    java: `public class Main { \n  public static void main(String[] args) { \n    System.out.println("Hello, World!");\n  }\n }`,
    cpp: `#include <iostream> \nusing namespace std;\nint main() {\n cout << "Hello, World!";\n return 0; \n}`,
  };

  // Set default code when the component mounts
  useEffect(() => {
    setSnippets(codeSnippets);
    setCode(codeSnippets[language]); // Set the default code for the default language (Python)
  }, []); // Only run once when the component mounts

  // Reset code snippet when language changes
  const handleLanguageChange = (e) => {
    const selectedLanguage = e.target.value;
    setLanguage(selectedLanguage);
    setCode(snippets[selectedLanguage] || ''); // Load code snippet for the selected language
  };

  const handleCodeChange = (value) => setCode(value);

  const handleStdinChange = (e) => setStdin(e.target.value);

  const runCode = async () => {
    setLoading(true);
    setOutput([]); // Clear previous output

    try {
      // Send the request to the Piston API
      const response = await axios.post('https://emkc.org/api/v2/piston/execute', {
        language, // Selected language
        version: '*', // Use the latest version available
        files: [
          {
            name: 'main', // Name of the file
            content: code, // Code content
          },
        ],
        stdin: stdin, // Input for stdin
      });

      const { run } = response.data;

      let newOutput = [];

      if (run && run.stdout) {
        newOutput.push({ type: 'stdout', message: run.stdout }); // Output from stdout
      } else if (run && run.stderr) {
        newOutput.push({ type: 'stderr', message: `Error: ${run.stderr}` }); // Output from stderr
      } else {
        newOutput.push({ type: 'stderr', message: 'No output or error occurred' });
      }

      setOutput(newOutput); // Set output as an array
    } catch (error) {
      console.error('Error executing code:', error);
      setOutput([{ type: 'stderr', message: `Error: ${error.message}` }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="editor-container">
      <div>
        <select onChange={handleLanguageChange} value={language}>
          <option value="python">Python</option>
          <option value="javascript">JavaScript</option>
          <option value="java">Java</option>
          <option value="cpp">C++</option>
        </select>
      </div>
      <div>
        <MonacoEditor
          value={code}
          onChange={handleCodeChange}
          language={language}
          theme="vs-dark"
          height="400px"
          options={{
            selectOnLineNumbers: true,
            minimap: { enabled: false },
          }}
        />
      </div>
      <div>
        <textarea
          value={stdin}
          onChange={handleStdinChange}
          rows={5}
          cols={50}
          placeholder="Input for your program (stdin)"
        ></textarea>
      </div>
      <div>
        <button onClick={runCode} disabled={loading}>
          {loading ? 'Running...' : 'Run Code'}
        </button>
      </div>
      <div>
        <h3>Output:</h3>
        {output.map((item, index) => (
          <pre key={index} style={{ color: item.type === 'stderr' ? 'red' : 'green' }}>
            {item.message}
          </pre>
        ))}
      </div>
    </div>
  );
};

export default CodeEditor;
