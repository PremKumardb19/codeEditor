// import React from "react";
// import { ChakraProvider } from "@chakra-ui/react";
// import CodeEditor from "./CodeEditor";

// const App = () => (
//   <ChakraProvider>
//     <CodeEditor />
//   </ChakraProvider>
// );

// export default App;
import React from "react";
import { ChakraProvider, extendTheme } from "@chakra-ui/react";
import CodeEditor from "./CodeEditor";

// Example theme extension (optional)
const theme = extendTheme({
  styles: {
    global: {
      body: {
        bg: "gray.50",
        color: "gray.800",
        fontFamily: "'Inter', sans-serif",
        lineHeight: "base",
      },
    },
  },
});

const App = () => (
  <ChakraProvider theme={theme}>
    <CodeEditor />
  </ChakraProvider>
);

export default App;

